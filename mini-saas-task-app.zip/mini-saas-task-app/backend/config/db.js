const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "taskmanager",
  password: "88400", // 👈 yaha apna password daal
  port: 5432,
});

module.exports = pool;