const express = require("express");
const router = express.Router();

const auth = require("../middleware/authMiddleware");

// 👇 sab controllers import
const {
  createTask,
  getTasks,
  updateTask,
  deleteTask
} = require("../controllers/taskController");

// 🔹 CREATE TASK
router.post("/", auth, createTask);

// 🔹 GET USER TASKS
router.get("/", auth, getTasks);

// 🔥 UPDATE TASK (status change)
router.put("/:id", auth, updateTask);

// 🔥 DELETE TASK
router.delete("/:id", auth, deleteTask);

module.exports = router;