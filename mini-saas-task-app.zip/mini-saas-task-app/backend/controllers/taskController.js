const pool = require("../config/db");

// CREATE TASK
exports.createTask = async (req, res) => {
  const { title, description } = req.body;
  const userId = req.user.userId;

  const task = await pool.query(
    "INSERT INTO tasks (title, description, user_id) VALUES ($1,$2,$3) RETURNING *",
    [title, description, userId]
  );

  res.json(task.rows[0]);
};

// GET TASKS (user specific)
exports.getTasks = async (req, res) => {
  const userId = req.user.userId;

  const tasks = await pool.query(
    "SELECT * FROM tasks WHERE user_id=$1",
    [userId]
  );

  res.json(tasks.rows);
};

// 🔥 UPDATE TASK (Pending → Completed)
exports.updateTask = async (req, res) => {
  const { id } = req.params;

  await pool.query(
    "UPDATE tasks SET status='completed' WHERE id=$1",
    [id]
  );

  res.json({ message: "Task updated" });
};

// 🔥 DELETE TASK
exports.deleteTask = async (req, res) => {
  const { id } = req.params;

  await pool.query(
    "DELETE FROM tasks WHERE id=$1",
    [id]
  );

  res.json({ message: "Task deleted" });
};